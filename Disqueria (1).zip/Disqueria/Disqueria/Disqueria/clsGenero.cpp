#include <iostream>
using namespace std;
#include "clsGenero.h"
#include "Funciones.h"

const char *Genero::getNombre(){
    return _nombre;
}
int  Genero::getIDGenero(){
    return _IDGenero;
}
bool Genero::getEstado(){
    return _estado;
}
////////////////////////////////////////////////////////////////////
void Genero::setIDGenero (int IDGenero){
    _IDGenero=IDGenero;
}
void Genero::setNombre (const char *nombre){
    strcpy(_nombre, nombre);
}
void Genero::setEstado (bool estado){
    _estado=estado;
}
////////////////////////////////////////////////////////////////////
void Genero::Mostrar(){
    cout<<"ID: "<<_IDGenero<<endl;
    cout<<"NOMBRE: "<<_nombre<<endl;
}

void Genero::Cargar(int id){
    cout<<"NOMBRE: ";
    setNombre(_nombre);
    cargarCadena(_nombre,30);
    setIDGenero(id);
    setEstado(true);

}
