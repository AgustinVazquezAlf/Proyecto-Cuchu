#ifndef CLSEMPLEADOS_H_INCLUDED
#define CLSEMPLEADOS_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
#include "clsPersonas.h"
using namespace std;

class Empleados : public Personas{
    private:
        int _dniEmpleado;
        float _sueldo;
    public:
        int getDniEmpleado();
        float getSueldo();
        void setDniEmpleado (int dniEmpleado);
        void setSueldo (float sueldo);
        void Mostrar();
        void Cargar(int dni);

};


#endif // CLSEMPLEADOS_H_INCLUDED
