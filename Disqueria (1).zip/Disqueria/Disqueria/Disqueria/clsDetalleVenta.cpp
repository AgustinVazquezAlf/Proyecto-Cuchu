#include <iostream>
using namespace std;
#include "funciones.h"
#include "clsDiscos.h"
int DetalleVenta::getCodigoDeBarras(){
    return _codigoDeBarras;
}

float DetalleVenta::getPrecio(){
    return _precio;
}

int DetalleVenta::getCantidad(){
    return _cantidad;
}

int DetalleVenta::getNumeroFactura(){
    return _numeroFactura;
}

bool DetalleVenta::getEstado(){
    return _estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DetalleVenta::setCodigoDeBarras (int codigoDeBarras){
    _codigoDeBarras=codigoDeBarras;
}

void DetalleVenta::setCantidad (int cantidad){
    _cantidad=cantidad;
}

void DetalleVenta::setPrecio (int precio){
    _precio=precio;
}

void DetalleVenta::setNumeroFactura (int numeroFactura){
    _numeroFactura=numeroFactura;
}

void DetalleVenta::setEstado (bool estado){
    _estado=estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void DetalleVenta::Mostrar(){
    cout<<"COD. DISCO: "<<_codigoDeBarras<<endl;
    cout<<"NUM. FACTURA : "<<_numeroFactura<<endl;
    cout<<"PRECIO: "<<_precio<<endl;
    cout<<"CANTIDAD: "<<_cantidad<<endl;
}

void DetalleVenta::Cargar(int codigo, int nF, float precio){
    int cantidad;
    cout<<"CANTIDAD: ";
    while(!PorSiFalla(cantidad)){
        cout<<"INGRESE LA CANTIDAD NUEVAMENTE: ";
    }
    setNumeroFactura(nF);
    setEstado(true);
    setCodigoDeBarras(codigo);
    setCantidad(cantidad);
    setPrecio(precio);

}
