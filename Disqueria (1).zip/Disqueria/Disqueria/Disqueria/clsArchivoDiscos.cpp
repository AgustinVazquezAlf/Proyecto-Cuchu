#include <iostream>
#include <cstring>
#include "clsDiscos.h"
#include "clsArchivoDiscos.h"
using namespace std;

ArchivoDiscos::ArchivoDiscos(const char *n){
    strcpy(nombre, n);
}

Discos ArchivoDiscos::leerRegistro(int pos){
    FILE *p;
    Discos obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setCodigoDeBarras(-2);
        return obj;
    }
    obj.setCodigoDeBarras(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoDiscos::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Discos);
}

int ArchivoDiscos::buscarRegistro(int cod){
    int cantReg = contarRegistros();
    Discos obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getCodigoDeBarras()==cod){
            return i;
        }
    }
    return -1;
}

bool ArchivoDiscos::grabarRegistro(Discos obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoDiscos::modificarRegistro(Discos obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoDiscos::listarRegistros(){
    int cantReg = contarRegistros();
    Discos obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}
