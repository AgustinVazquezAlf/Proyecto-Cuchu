#include "clsFecha.h"
#include <iostream>
#include <string.h>
using namespace std;
#include "clsDiscos.h"
#include "Funciones.h"


bool  Discos::getEstado(){
    return _estado;
}

int   Discos::getCodigoDeBarras(){
    return _codigoDeBarras;
}

int   Discos::getIDInterprete(){
    return _IDInterprete;
}

const char  *Discos::getNombreDisco(){
    return _nombreDelDisco;
}

int   Discos::getIDGenero(){
    return _IDGenero;
}

Fecha   Discos::getFechaDeLanzamiento(){
    return _fechaDeLanzamiento;
}

const char  *Discos::getOrigen(){
    return _origen;
}

float Discos::getPrecio(){
    return _precio;
}

int   Discos::getFormato(){
    return _formato;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void  Discos::setCodigoDeBarras (int codigoDeBarras){
    _codigoDeBarras=codigoDeBarras;
}

void  Discos::setIDInterprete (int IDInterprete){
    _IDInterprete=IDInterprete;
}

void  Discos::setIDGenero (int IDGenero){
    _IDGenero=IDGenero;
}
void Discos::setNombreDisco (const char *nombreDelDisco){
    strcpy(_nombreDelDisco, nombreDelDisco);
}

void Discos::setOrigen (const char *origen){
    strcpy(_origen, origen);
}

void  Discos::setFechaDeLanzamiento (Fecha fechaDeLanzamiento){
    _fechaDeLanzamiento=fechaDeLanzamiento;
}

void  Discos::setPrecio (float precio){
    _precio=precio;
}

void  Discos::setFormato (int formato){
    _formato=formato;
}

void  Discos::setEstado (bool estado){
    _estado=estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void  Discos::Mostrar(){
    cout<<"COD. DE BARRAS: "<<_codigoDeBarras<<endl;
    cout<<"NOMBRE DEL DISCO: "<<_nombreDelDisco<<endl;
    cout<<"COD. INTERPRETE: "<<_IDInterprete<<endl;
    cout<<"COD. GENERO: "<<_IDGenero<<endl;
    _fechaDeLanzamiento.Mostrar();
    cout<<"ORIGEN: "<<_origen<<endl;
    cout<<"FORMATO: "<<_formato<<endl;
    cout<<"PRECIO: "<<_precio<<endl;
}

void  Discos::Cargar(int codigo){
    int codInterprete, codGenero, formato;
    float precio;
    cout<<"NOMBRE DEL DISCO: ";
    cargarCadena(_nombreDelDisco,30);
    cout<<"COD. INTERPRETE: ";
    cin>>codInterprete;
    if(!comprobarInterprete(codInterprete)){
        cout<<"EL ID DE INTERPRETE INGRESADO NO EXISTE EN EL ARCHIVO DE INTERPRETES"<<endl;
        return;
    }
    cout<<"COD. GENERO: ";
    cin>>codGenero;
    if(!comprobarGenero(codGenero)){
        cout<<"EL ID DE GENERO INGRESADO NO EXISTE EN EL ARCHIVO DE GENEROS"<<endl;
        return;
    }
    cout<<"ORIGEN: ";
    cargarCadena(_origen,30);
    cout<<"PRECIO: ";
    while(!PorSiFallaPrecio(precio)){
        cout<<"INGRESE EL PRECIO NUEVAMENTE: ";
    }
    cout<<"FORMATO (int): ";
    while(!PorSiFalla(formato)){
    cout<<"INGRESE EL FORMATO NUEVAMENTE: ";
    }
    cout<<"FECHA LANZAMIENTO: "<<endl;
    _fechaDeLanzamiento.Cargar();
    setEstado(true);
    setCodigoDeBarras(codigo);
    setFormato(formato);
    setPrecio(precio);
    setIDGenero(codGenero);
    setIDInterprete(codInterprete);
}

