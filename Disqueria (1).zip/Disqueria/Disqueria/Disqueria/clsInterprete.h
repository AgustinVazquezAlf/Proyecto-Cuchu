#ifndef CLSINTERPRETE_H_INCLUDED
#define CLSINTERPRETE_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
#include "clsPersonas.h"
using namespace std;

class Interprete : public Personas{
    private:
        int _IDInterprete;
        Fecha _fechaNacimiento;
    public:
        int getIDInterprete();
        Fecha getFechaNacimiento();
        void setIdInterprete (int IDInterprete);
        void setFechaNacimiento (Fecha fechaNacimiento);
        void Mostrar();
        void Cargar(int id);
};


#endif // CLSINTERPRETE_H_INCLUDED
