#ifndef CLSPERSONAS_H_INCLUDED
#define CLSPERSONAS_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Personas
{
public:
    Personas();
    ~Personas();
    const char* getNombre();
    const char* getApellido();
    bool getEstado();
    void setEstado(bool estado);
    virtual void Mostrar();
    virtual void Cargar();
    void setNombre (const char *nombre);
    void setApellido (const char *apellido);

private:
    char _nombre[30];
    char _apellido[30];
    bool _estado;
};



#endif // CLSPERSONAS_H_INCLUDED
