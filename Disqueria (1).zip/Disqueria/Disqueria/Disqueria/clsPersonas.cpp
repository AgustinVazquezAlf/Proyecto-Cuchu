#include <iostream>
#include "clsPersonas.h"
#include "Funciones.h"
#include<string.h>
using namespace std;


Personas::Personas(){

}

Personas::~Personas(){

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const char* Personas::getNombre(){
    return _nombre;
}
const char* Personas::getApellido(){
    return _apellido;
}

bool Personas::getEstado(){
    return _estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Personas::setEstado(bool estado){
    _estado=estado;
}

void Personas::setNombre (const char *nombre){
    strcpy(_nombre, nombre);
}

void Personas::setApellido (const char *apellido){
    strcpy(_apellido, apellido);
}

void Personas::Cargar(){
    cout<<"NOMBRE: ";
    cargarCadena(_nombre,30);
    cout<<"APELLIDO: ";
    cargarCadena(_apellido,30);
    setNombre(_nombre);
    setApellido(_apellido);
    setEstado(true);
}

void Personas::Mostrar(){
    cout<<"NOMBRE: "<<getNombre()<<endl;
    cout<<"APELLIDO: "<<getApellido()<<endl;
}
