#include <iostream>
#include <cstring>
#include "clsEmpleados.h"
#include "clsArchivoEmpleados.h"
using namespace std;

ArchivoEmpleados::ArchivoEmpleados(const char *n){
    strcpy(nombre, n);
}

Empleados ArchivoEmpleados::leerRegistro(int pos){
    FILE *p;
    Empleados obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setDniEmpleado(-2);
        return obj;
    }
    obj.setDniEmpleado(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoEmpleados::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Empleados);
}

int ArchivoEmpleados::buscarRegistro(int dni){
    int cantReg = contarRegistros();
    Empleados obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getDniEmpleado()==dni){
            return i;
        }
    }
    return -1;
}

bool ArchivoEmpleados::grabarRegistro(Empleados obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoEmpleados::modificarRegistro(Empleados obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoEmpleados::listarRegistros(){
    int cantReg = contarRegistros();
    Empleados obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}


