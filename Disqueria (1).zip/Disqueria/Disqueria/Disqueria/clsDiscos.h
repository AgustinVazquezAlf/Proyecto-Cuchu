#ifndef CLSDISCOS_H_INCLUDED
#define CLSDISCOS_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Discos{
    private:
        int _codigoDeBarras;
        int _IDInterprete;
        int _IDGenero;
        char _nombreDelDisco[30];
        Fecha _fechaDeLanzamiento;
        char _origen[30];
        float _precio;
        int _formato;
        bool _estado;
    public:
        bool getEstado();
        int getCodigoDeBarras();
        int getIDInterprete();
        const char *getNombreDisco();
        int getIDGenero();
        Fecha getFechaDeLanzamiento();
        const char *getOrigen();
        float getPrecio();
        int getFormato();
        void setCodigoDeBarras (int codigoDeBarras);
        void setIDInterprete (int IDInterprete);
        void setIDGenero (int IDGenero);
        void setNombreDisco (const char *nombreDelDisco);
        void setFechaDeLanzamiento (Fecha fechaDeLanzamiento);
        void setOrigen (const char *origen);
        void setPrecio (float precio);
        void setFormato (int formato);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar(int codigo);
};

#endif // CLSDISCOS_H_INCLUDED
