#include <iostream>
#include <cstring>
#include "clsGenero.h"
#include "clsArchivoGenero.h"
using namespace std;

ArchivoGenero::ArchivoGenero(const char *n){
    strcpy(nombre, n);
}

Genero ArchivoGenero::leerRegistro(int pos){
    FILE *p;
    Genero obj;
    p=fopen(nombre ,"rb"); //�rb�: Apertura para lectura de un archivo binario (read). El archivo debe existir.
    if(p==nullptr){
        obj.setIDGenero(-2);
        return obj;
    }
    obj.setIDGenero(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoGenero::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Genero);
}

int ArchivoGenero::buscarRegistro(int id){
    int cantReg = contarRegistros();
    Genero obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getIDGenero()==id){
            return i;
        }
    }
    return -1;
}

bool ArchivoGenero::grabarRegistro(Genero obj){
    FILE *p;
    p=fopen(nombre, "ab"); //�ab�: Apertura de un archivo binario para agregar registros (append). Si no existe lo crea.
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoGenero::modificarRegistro(Genero obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+"); //(con �rb+� se abre un archivo binario para lectura y escritura
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoGenero::listarRegistros(){
    int cantReg = contarRegistros();
    Genero obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}

