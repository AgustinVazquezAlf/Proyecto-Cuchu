#include <iostream>
#include<string.h>
#include "Funciones.h"
#include "clsClientes.h"
#include "clsArchivoClientes.h"
#include "clsInterprete.h"
#include "clsArchivoInterpretes.h"
#include "clsGenero.h"
#include "clsArchivoGenero.h"
#include "clsDiscos.h"
#include "clsArchivoDiscos.h"
#include "clsEmpleados.h"
#include "clsArchivoEmpleados.h"
#include "clsVentas.h"
#include "clsArchivoVentas.h"
#include "clsArchivoDetalleVenta.h"
#include "rlutil.h"
using namespace std;
///PEDRO///ADRIEL///YANET//FEDERICO


void color(){
rlutil::setBackgroundColor(rlutil::MAGENTA);
rlutil::setColor(rlutil::WHITE);
}

///CARGAR CADENA
void capitalizarPrimeraLetra(char* pal) {
    if (pal[0] != '\0') {
        pal[0] = toupper(pal[0]);  // Convierte la primera letra (posicion) a may�scula
    }
    for (int i = 1; pal[i] != '\0'; i++) {
        pal[i] = tolower(pal[i]); // Convierte el resto de las letras a min�sculas
    }
}

void cargarCadena(char *pal, int tam) {
    int i;
    fflush(stdin); // Limpia el bufer de entrada antes de comenzar la carga
    for (i = 0; i < tam; i++) {
        pal[i] = cin.get(); // Lee un caracter de la entrada y lo guarda en `pal[i]` (osea en el vector de palabra
        capitalizarPrimeraLetra(pal);
        if (pal[i] == '\n') break; // Si se presiona "enter", se detiene la carga
    }
    pal[i] = '\0'; // Marca el final de la cadena con `\0`
    fflush(stdin); // Limpia el b�fer de entrada despu�s de la carga
}

float obtenerPrecioDisco(int codigo) {
    ArchivoDiscos arc;
    Discos obj;
    int cantReg = arc.contarRegistros();
    for (int i = 0; i < cantReg; i++) {
        obj = arc.leerRegistro(i);
        if (obj.getCodigoDeBarras() == codigo) {
            return obj.getPrecio();
        }
    }
    cout<<"INGRESE UN CODIGO QUE ESTE EN EL ARCHIVO DE DISCOS"<<endl;
    return -1;
}

///PorSIFalla vendria a ser una validadicion de que el usuario este ingresando un numero
bool PorSiFalla(int &VALORGENERICO){
    cin>>VALORGENERICO;
    if(cin.fail()||VALORGENERICO<0){
    cin.clear();/// limpia el estado de error
    cin.ignore(10000,'\n');/// lo que hace es ignorar (borrar) el caracter, hasta el salto de l�nea
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (ENTERO)."<<endl;
    return false;
    }
    cin.ignore(10000,'\n');
    return true;
}

bool PorSiFallaPrecio(float &VALORGENERICO){
    cin>>VALORGENERICO;
    if(cin.fail()||VALORGENERICO<0){
    cin.clear();/// limpia el estado de error
    cin.ignore(10000,'\n');/// lo que hace es ignorar (borrar) el caracter, hasta el salto de l�nea
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (ENTERO)."<<endl;
    return false;
    }
    cin.ignore(10000,'\n');
    return true;
}

bool PorSiFallaDetalleVenta(int &VALORGENERICO){
    cin>>VALORGENERICO;
    if(cin.fail()||VALORGENERICO<0||!comprobarDisco(VALORGENERICO)){
    cin.clear();/// limpia el estado de error
    cin.ignore(10000,'\n');/// lo que hace es ignorar (borrar) el caracter, hasta el salto de l�nea
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN CODIGO QUE ESTE EN EL ARCHIVO DE DISCOS."<<endl;
    return false;
    }
    cin.ignore(10000,'\n');
    return true;
}

bool porSiFallaDia(int &dia){
cin>>dia;
    if(dia>31||dia<1){
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UNA FECHA VALIDA."<<endl;
    return false;
    }
    return true;
}

bool porSiFallaMes(int &mes){
cin>>mes;
    if(mes>12||mes<1){
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UNA FECHA VALIDA."<<endl;
    return false;
    }
    return true;
}

bool porSiFallaAnio(int &anio){
cin>>anio;
    if(anio<1){
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UNA FECHA VALIDA."<<endl;
    return false;
    }
    return true;
}

///ALTAS
void altaInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID NUEVAMENTE: ";
    }
    if(arc.buscarRegistro(id)>=0){
    cout<<"EL ID INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
    return;
    }
    obj.Cargar(id);
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaGenero(){
    Genero obj;
    ArchivoGenero arc;
    int id;
    cout<<"INGRESE EL ID: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID NUEVAMENTE: ";
    }
    //si el ID ya existe en el archivo
    int pos=arc.buscarRegistro(id);

    if(pos>=0){
        obj=arc.leerRegistro(pos);

        if (obj.getEstado()==false){
            char opcion;
            cout << "EL GENERO INGRESADO SE ENCUENTRA DADO DE BAJA, DESEA DARLO DE ALTA NUEVAMENTE? (S/N)"<<endl;
            cin>> opcion;
            if (opcion == 'S' || opcion =='s'){
                obj.setEstado(true);
                arc.modificarRegistro(obj,pos);
                cout<<"EL GENERO FUE DADO DE ALTA NUEVAMENTE"<<endl;
        }else{
                cout<<"NO SE REALIZARON CAMBIOS"<<endl;
            } }else{
                cout<<"EL CODIGO INGRESADO YA EXISTE Y ESTA ACTIVO"<<endl;
            }
    }else{
    //si el ID no existe en el archivo
    obj.Cargar(id);
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
    }
}

void altaDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO NUEVAMENTE: ";
    }
    if(arc.buscarRegistro(codigo)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar(codigo);
    if(obj.getEstado()==false){
        cout<<"SE CANCELA EL ALTA DEL REGISTRO"<<endl;
    return;
    }
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI NUEVAMENTE: ";
    }
    if(arc.buscarRegistro(dni)>=0){
        cout<<"EL DNI INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar(dni);
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL DNI: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI NUEVAMENTE: ";
    }
    if(arc.buscarRegistro(dni)>=0){
        cout<<"EL DNI INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar(dni);
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }

}

void altaVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA NUEVAMENTE: ";
    }
    if(arc.buscarRegistro(numeroFactura)>=0){
        cout<<"EL NUMERO DE FACTURA INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar(numeroFactura);
    if(obj.getEstado()==false){
    cout<<"SE CANCELA EL ALTA DEL REGISTRO"<<endl;
    return;
    }

    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

DetalleVenta altaDetalleVenta(int numeroFactura){
    DetalleVenta obj;
    ArchivoDetalleVenta arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DE BARRAS: ";
    while(!PorSiFallaDetalleVenta(codigo)){
        cout<<"INGRESE EL CODIGO NUEVAMENTE: ";
    }
    float precio = obtenerPrecioDisco(codigo);
    obj.Cargar(codigo, numeroFactura, precio);
    if(obj.getEstado()==false){
    cout<<"SE CANCELA EL ALTA DEL REGISTRO"<<endl;
    return obj;
    }

    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
    return obj;
}

///BAJAS
void bajaInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID DEL INTERPRETE A DAR DE BAJA: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL INTERPRETE A DAR DE BAJA NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL INTERPRETE INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }else {
        char opcion;
            cout << "EL INTERPRETE NOMBRE: "<<obj.getNombre()<<" APELLIDO: "<<obj.getApellido()<<" ,SEGURO DESEA DARLO DE BAJA?(S/N)"<<endl;
            cin>> opcion;
            if (opcion == 'S' || opcion =='s'){
                obj.setEstado(false);
                arc.modificarRegistro(obj,pos);
                cout<<"EL INTERPRETE SE A DADO DE BAJA CORRECTAMENTE..."<<endl;
        }else{
        return;}
    }
}

void bajaGenero(){
    Genero obj;
    ArchivoGenero arc;
    int id;
    cout<<"INGRESE EL ID DEL GENERO A DAR DE BAJA: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL GENERO A DAR DE BAJA NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL GENERO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A DAR DE BAJA: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A DAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI DEL EMPLEADO A DAR DE BAJA: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL EMPLEADO A DAR DE BAJA NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL EMPLEADO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL DNI DEL CLIENTE A DAR DE BAJA: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL CLIENTE A DAR DE BAJANUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL CLIENTE INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaVenta(){
    Ventas obj;
    ArchivoVentas arc;
    DetalleVenta obj2;
    ArchivoDetalleVenta arc2;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A DAR DE BAJA: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A DAR DE BAJA NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA INGRESADA YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);

    int pos2 = arc2.buscarRegistro(numeroFactura);
    if(pos2<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj2 = arc2.leerRegistro(pos);
    if(obj2.getEstado()==false){
        cout<<"LA VENTA INGRESADA YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj2.setEstado(false);
    arc2.modificarRegistro(obj2, pos2);
}

void bajaDetalleVenta(){
    DetalleVenta obj;
    ArchivoDetalleVenta arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DE BARRAS DE LA VENTA A DAR DE BAJA: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DE BARRAS DE LA VENTA A DAR DE BAJA NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA INGRESADA YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

///LISTAR
void listarInterpretes(){
    ArchivoInterpretes arc;
    arc.listarRegistros();
}

void listarGeneros(){
    ArchivoGenero arc;
    arc.listarRegistros();
}

void listarDiscos(){
    ArchivoDiscos arc;
    arc.listarRegistros();
}

void listarEmpleados(){
    ArchivoEmpleados arc;
    arc.listarRegistros();
}

void listarClientes(){
    ArchivoClientes arc;
    arc.listarRegistros();
}

void listarVentas(){
    ArchivoVentas arc;
    arc.listarRegistros();
}

void listarDetalleVentas(){
    ArchivoDetalleVenta arc;
    arc.listarRegistros();
}

///MODIFICAR

void modificarNombreInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL INTERPRETE YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    char nombre[30];
    cout<<"INGRESE EL NOMBRE DEL INTERPRETE: "<<endl;
    cargarCadena(nombre,30);
    obj.setNombre(nombre);
    arc.modificarRegistro(obj, pos);
}

void modificarApellidoInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL INTERPRETE YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    char apellido[30];
    cout<<"INGRESE EL APELLIDO DEL GENERO: "<<endl;
    cargarCadena(apellido,30);
    obj.setApellido(apellido);
    arc.modificarRegistro(obj, pos);
}

void modificarFechaInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL INTERPRETE A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL INTERPRETE YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    Fecha fechaNacimiento;
    cout<<"INGRESE LA FECHA NUEVA ";
    fechaNacimiento.Cargar();
    obj.setFechaNacimiento(fechaNacimiento);
    arc.modificarRegistro(obj, pos);
}

void modificarNombreGenero(){
    Genero obj;
    ArchivoGenero arc;
    int id;
    cout<<"INGRESE EL ID DEL GENERO A CAMBIAR: ";
    while(!PorSiFalla(id)){
        cout<<"INGRESE EL ID DEL GENERO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL GENERO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    char nombre[30];
    cout<<"INGRESE EL NOMBRE DEL GENERO: "<<endl;
    cargarCadena(nombre,30);
    obj.setNombre(nombre);
    arc.modificarRegistro(obj, pos);
}

void modificarInterpreteDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    int IDInterprete;
    cout<<"INGRESE EL ID DEL INTERPRETE NUEVO ";
    cin>>IDInterprete;
    obj.setIDInterprete(IDInterprete);
    arc.modificarRegistro(obj, pos);
}

void modificarGeneroDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    int IDGenero;
    cout<<"INGRESE EL ID DEL GENERO NUEVO ";
    cin>>IDGenero;
    obj.setIDGenero(IDGenero);
    arc.modificarRegistro(obj, pos);
}

void modificarOrigenDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    char origen[30];
    cout<<"INGRESE EL ORIGEN DEL DISCO: "<<endl;
    cargarCadena(origen,30);
    obj.setOrigen(origen);
    arc.modificarRegistro(obj, pos);
}

void modificarPrecioDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    int precio;
    cout<<"INGRESE EL PRECIO NUEVO ";
    cin>>precio;
    obj.setPrecio(precio);
    arc.modificarRegistro(obj, pos);
}

void modificarFormatoDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    int formato;
    cout<<"INGRESE EL FORMATO NUEVO ";
    cin>>formato;
    obj.setFormato(formato);
    arc.modificarRegistro(obj, pos);
}

void modificarFechaDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DEL DISCO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    Fecha fechaLanzamiento;
    cout<<"INGRESE LA FECHA NUEVA ";
    fechaLanzamiento.Cargar();
    obj.setFechaDeLanzamiento(fechaLanzamiento);
    arc.modificarRegistro(obj, pos);
}

void modificarNombreCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL DNI DEL CLIENTE A CAMBIAR: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL CLIENTE A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL CLIENTE YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    char nombre[30];
    cout<<"INGRESE EL NOMBRE DEL CLIENTE: "<<endl;
    cargarCadena(nombre,30);
    obj.setNombre(nombre);
    arc.modificarRegistro(obj, pos);
}

void modificarApellidoCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL DNI DEL CLIENTE A CAMBIAR: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL CLIENTE A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL CLIENTE YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    char apellido[30];
    cout<<"INGRESE EL APELLIDO DEL CLIENTE: "<<endl;
    cargarCadena(apellido,30);
    obj.setApellido(apellido);
    arc.modificarRegistro(obj, pos);
}

void modificarNombreEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL EMPLEADO YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    char nombre[30];
    cout<<"INGRESE EL NOMBRE DEL EMPLEADO: "<<endl;
    cargarCadena(nombre,30);
    obj.setNombre(nombre);
    arc.modificarRegistro(obj, pos);
}

void modificarApellidoEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL EMPLEADO YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    char apellido[30];
    cout<<"INGRESE EL NOMBRE DEL GENERO: "<<endl;
    cargarCadena(apellido,30);
    obj.setApellido(apellido);
    arc.modificarRegistro(obj, pos);
}

void modificarSueldoEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR: ";
    while(!PorSiFalla(dni)){
        cout<<"INGRESE EL DNI DEL EMPLEADO A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL EMPLEADO YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    int sueldo;
    cout<<"INGRESE EL SUELDO NUEVO ";
    cin>>sueldo;
    obj.setSueldo(sueldo);
    arc.modificarRegistro(obj, pos);
}

void modificarDNIEmpleadoVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    int DNIEmpleado;
    cout<<"INGRESE EL DNI NUEVO ";
    cin>>DNIEmpleado;
    obj.setDniEmpleado(DNIEmpleado);
    arc.modificarRegistro(obj, pos);
}

void modificarDNIClienteVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    int DNICliente;
    cout<<"INGRESE EL DNI NUEVO ";
    cin>>DNICliente;
    obj.setDniCliente(DNICliente);
    arc.modificarRegistro(obj, pos);
}

void modificarImporteVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    int importe;
    cout<<"INGRESE EL IMPORTE NUEVO ";
    cin>>importe;
    obj.setImporte(importe);
    arc.modificarRegistro(obj, pos);
}

void modificarFechaVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR: ";
    while(!PorSiFalla(numeroFactura)){
        cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A CAMBIAR NUEVAMENTE: ";
    }
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA YA SE ENCUENTRA DADA DE BAJA"<<endl;
        return;
    }
    Fecha fechaEmision;
    cout<<"INGRESE LA FECHA NUEVA ";
    fechaEmision.Cargar();
    obj.setFechaEmision(fechaEmision);
    arc.modificarRegistro(obj, pos);
}



///ORDENAR INT�RPRETES
void ordenarInterpretePorFecha(){///casi listo /// Listo By Adriel
    ArchivoInterpretes arcI;
    int cantRegistrosI=arcI.contarRegistros();
    Interprete* interpretes=new Interprete[cantRegistrosI]; //vector dinamico para los interpretes
    ///CARGAR INTERPRETES
    for(int i=0;i<cantRegistrosI;i++){
        interpretes[i]=arcI.leerRegistro(i);
    }
    ///ORDENA INTERPRETES POR FECHA
    for(int i=0;i<cantRegistrosI-1;i++){
        for(int j=i+1;j<cantRegistrosI;j++){
            if(interpretes[i].getFechaNacimiento()<interpretes[j].getFechaNacimiento()){
                Interprete auxI=interpretes[i];
                interpretes[i]=interpretes[j];
                interpretes[j]=auxI;
            }
        }
    }
    ///MOSTRAR INT�RPRETE
    for(int i=0;i<cantRegistrosI;i++){
        if(interpretes[i].getEstado()==true){
            cout<<"Interprete "<<i+1<<" "; interpretes[i].Mostrar(); cout<<endl;
        }
    }
    delete[] interpretes;
}

void ordenarInterpretePorAlfabetico(){//listo (completo).
    ArchivoInterpretes arc;
    int cantReg=arc.contarRegistros();
    Interprete* vecInterprete=new Interprete[cantReg];
    for (int i=0;i<cantReg;i++){
        vecInterprete[i]=arc.leerRegistro(i);
    }
    ///ORDENAR ALFABETICAMENTE
    for (int i=0;i<cantReg-1;i++){
        for (int a=i+1;a<cantReg;a++){
            if(strcmp(vecInterprete[i].getNombre(),vecInterprete[a].getNombre())>0){
                Interprete temp=vecInterprete[i];
                vecInterprete[i]=vecInterprete[a];
                vecInterprete[a]=temp;
            }
        }
    }
    cout<<" LISTA DE INTERPRETES ORDENADA ALFABETICAMENTE "<<endl;
    for (int i=0;i<cantReg;i++){
        if (vecInterprete[i].getEstado()==true){
            cout<<"Interprete "<<i+1<<" "; vecInterprete[i].Mostrar(); cout<<endl;
        }
    }
    delete []vecInterprete;
}

void ordenarInterpretePorCantidadDiscos(){//listo (completo)
    ArchivoInterpretes arcI;
    ArchivoDiscos arcD;
    int cantRegistrosI=arcI.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Interprete* interpretes=new Interprete[cantRegistrosI];
    int* cantDiscos=new int[cantRegistrosI];
    ///CARGAR INTERPRETES
    for(int i=0;i<cantRegistrosI;i++){
        interpretes[i]=arcI.leerRegistro(i);
        cantDiscos[i]=0;
    }
    ///CONTADOR DE DISCOS POR INTERPRETE
    for(int i=0;i<cantRegistrosI;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if (objD.getIDInterprete()==interpretes[i].getIDInterprete()){
                cantDiscos[i]++;
            }
        }
    }
    ///ORDENAR INTERPRETES POR CANTIDAD DE DISCOS
    for(int i=0;i<cantRegistrosI-1;i++){
        for(int j=i+1;j<cantRegistrosI;j++){
            if (cantDiscos[i]<cantDiscos[j]){
                Interprete auxI=interpretes[i];
                interpretes[i]=interpretes[j];
                interpretes[j]=auxI;
                int auxD=cantDiscos[i];
                cantDiscos[i]=cantDiscos[j];
                cantDiscos[j]=auxD;
            }
        }
    }
 ///MOSTRAR INTERPRETES ORDENADOS
    for(int i=0;i<cantRegistrosI;i++){
        if(interpretes[i].getEstado()==true){
        cout<<interpretes[i].getNombre()<<": "<<cantDiscos[i]<<" discos"<<endl;
        }
    }
    delete[] interpretes;
    delete[] cantDiscos;
}

///ORDENAR G�NEROS
void ordenarGeneroPorAlfabetico(){//listo(completo)
    ArchivoGenero arc;
    int cantReg=arc.contarRegistros();
    Genero* vecGenero=new Genero[cantReg];
    for (int i=0;i<cantReg;i++){
        vecGenero[i]=arc.leerRegistro(i);
    }
    ///ORDENAR ALFABETICAMENTE
    for (int i=0;i<cantReg-1;i++){
        for (int a=i+1;a<cantReg;a++){
            if(strcmp(vecGenero[i].getNombre(),vecGenero[a].getNombre())>0){
                Genero temp=vecGenero[i];
                vecGenero[i]=vecGenero[a];
                vecGenero[a]=temp;
            }
        }
    }
    cout<<" LISTA DE GENEROS ORDENADA ALFABETICAMENTE "<<endl;
    for (int i=0;i<cantReg;i++){
        if(vecGenero[i].getEstado()==true){
        vecGenero[i].Mostrar(); cout<<endl;
        }
    }
    delete []vecGenero;
}

void ordenarGeneroPorCantidadDiscos(){//listo(completo)
    ArchivoGenero arcG;
    ArchivoDiscos arcD;
    int cantRegistrosG=arcG.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Genero* generos=new Genero[cantRegistrosG];
    int* cantDiscos=new int[cantRegistrosG];
    ///CARGAR GENEROS
    for(int i=0;i<cantRegistrosG;i++){
        generos[i]=arcG.leerRegistro(i);
        cantDiscos[i]=0;
    }
     ///CONTADOSR DE DISCOS POR GENERO
    for(int i=0;i<cantRegistrosG;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if(objD.getIDGenero()==generos[i].getIDGenero()){
                cantDiscos[i]++;
            }
        }
    }
    ///ORDENAR GENEROS POR CANTIDAD DE DISCOS
    for(int i=0;i<cantRegistrosG-1;i++){
        for(int j=i+1;j<cantRegistrosG;j++){
            if(cantDiscos[i]<cantDiscos[j]){
                Genero auxG=generos[i];
                generos[i]=generos[j];
                generos[j]=auxG;
                int auxD=cantDiscos[i];
                cantDiscos[i]=cantDiscos[j];
                cantDiscos[j]=auxD;
            }
        }
    }
    ///MOSTRAR GENEROS POR CNTIDAD DE DISCOS
    for(int i=0;i<cantRegistrosG;i++){
        if(generos[i].getEstado()==true){
            cout<<generos[i].getNombre()<<": "<<cantDiscos[i]<<" discos"<<endl;
        }
    }
    delete[] generos;
    delete[] cantDiscos;
}

///ORDENAR DISCOS
void ordenarDiscoPorAlfabetico(){///casi listo(muestra dos posiciones mas del vector de las que deberia) /// Listo by adriel
    ArchivoDiscos arc;
    int cantReg=arc.contarRegistros();
    Discos* vecDiscos=new Discos[cantReg];
    for (int i=0;i<cantReg;i++){
        vecDiscos[i]=arc.leerRegistro(i);
    }
    ///ORDENAR ALFABETICAMENTE
    for (int i=0;i<cantReg-1;i++){
        for (int a=i+1;a<cantReg;a++){
            if(strcmp(vecDiscos[i].getNombreDisco(),vecDiscos[a].getNombreDisco())>0){
                Discos temp=vecDiscos[i];
                vecDiscos[i]=vecDiscos[a];
                vecDiscos[a]=temp;
            }
        }
    }
    cout<<" LISTA DE DISCOS ORDENADA ALFABETICAMENTE "<<endl;
    for (int i=0;i<cantReg;i++){
        if (vecDiscos[i].getEstado()==true){
            vecDiscos[i].Mostrar(); cout<<endl;
            cout<<endl;
        }
    }
    delete []vecDiscos;
}

void ordenarDiscoPorFecha(){///casi listo /// Listo By Adriel
    ArchivoDiscos arcD;
    int cantRegistrosD=arcD.contarRegistros();
    Discos* discos=new Discos[cantRegistrosD];
    ///CARGAR DISCOS
    for(int i=0;i<cantRegistrosD;i++){
        discos[i]=arcD.leerRegistro(i);
    }
    ///ORDENAR DISCOS POR FECHAS
    for(int i=0;i<cantRegistrosD-1;i++){
        for(int j=i+1;j<cantRegistrosD;j++){
            if(discos[i].getFechaDeLanzamiento()<discos[j].getFechaDeLanzamiento()){
                Discos auxD=discos[i];
                discos[i]=discos[j];
                discos[j]=auxD;
            }
        }
    }
    ///MOSTRAR DISCOS POR FECHAS
    for(int i=0;i<cantRegistrosD;i++){
        if(discos[i].getEstado()==true){
            discos[i].Mostrar(); cout <<endl;
        }
    }
    delete[] discos;
}

void ordenarDiscoPorPrecio(){///casi listo(muestra dos posiciones mas del vector de las que deberia) ///sigo sin entender porque te muestra mas de los que deberia pero a mi no. By Adriel
    ArchivoDiscos arcD;
    int cantRegistrosD=arcD.contarRegistros();
    Discos* discos=new Discos[cantRegistrosD];
    ///CARGAR DISCOS
    for(int i=0;i<cantRegistrosD;i++){
        discos[i]=arcD.leerRegistro(i);
    }
    ///ORDENAR DISCOS POR PRECIO
    for(int i=0;i<cantRegistrosD-1;i++){
        for(int j=i+1;j<cantRegistrosD;j++){
            if (discos[i].getPrecio()>discos[j].getPrecio()){
                Discos auxD=discos[i];
                discos[i]=discos[j];
                discos[j]=auxD;
            }
        }
    }
    ///MOSRAR DISCOS ORDENADOS
    for(int i=0;i<cantRegistrosD;i++){
        if(discos[i].getEstado()==true){
            discos[i].Mostrar(); cout <<endl;
        }
    }
    delete[] discos;
}

///ORDENAR EMPLEADOS
void ordenarEmpleadoPorAlfabetico(){//listo(completo)
    ArchivoEmpleados arc;
    int cantReg=arc.contarRegistros();
    Empleados* vecEmpleados=new Empleados[cantReg];
    for (int i=0;i<cantReg;i++){
        vecEmpleados[i]=arc.leerRegistro(i);
    }
    ///ORDENAR ALFABETICAMENTE
    for (int i=0;i<cantReg-1;i++){
        for (int a=i+1;a<cantReg;a++){
            if(strcmp(vecEmpleados[i].getNombre(),vecEmpleados[a].getNombre())>0){
                Empleados temp=vecEmpleados[i];
                vecEmpleados[i]=vecEmpleados[a];
                vecEmpleados[a]=temp;
            }
        }
    }
    cout<<" LISTA DE EMPLEADOS ORDENADA ALFABETICAMENTE "<<endl;
    for (int i=0;i<cantReg;i++){
        if (vecEmpleados[i].getEstado()==true){
            vecEmpleados[i].Mostrar(); cout<<endl;
        }
    }
    delete []vecEmpleados;
}

void ordenarEmpleadoPorDNI(){//listo(completo)
    ArchivoEmpleados arcE;
    int cantRegistrosE=arcE.contarRegistros();
    Empleados* empleados=new Empleados[cantRegistrosE];
    ///CARGAR EMPLEADOS
    for(int i=0;i<cantRegistrosE;i++){
        empleados[i]=arcE.leerRegistro(i);
    }
    ///ORDENAR EMPLEADOS POR DNI
    for(int i=0;i<cantRegistrosE-1;i++){
        for(int j=i+1;j<cantRegistrosE;j++){
            if(empleados[i].getDniEmpleado()>empleados[j].getDniEmpleado()){
                Empleados auxE=empleados[i];
                empleados[i]=empleados[j];
                empleados[j]=auxE;
            }
        }
    }
     ///MOSTRAR EMPLEADOS
    for(int i=0;i<cantRegistrosE;i++){
        if (empleados[i].getEstado()==true) {
            empleados[i].Mostrar(); cout<<endl;
        }
    }
    delete[] empleados;
}

void ordenarEmpleadoPorSueldo(){//listo(completo)
    ArchivoEmpleados arcE;
    int cantRegistrosE=arcE.contarRegistros();
    Empleados* empleados=new Empleados[cantRegistrosE];
    ///CARGAR EMPLEADOS
    for(int i=0;i<cantRegistrosE;i++){
        empleados[i]=arcE.leerRegistro(i);
    }
    ///ORDENAR EMPLEADOS POR SUELDO
    for(int i=0;i<cantRegistrosE-1;i++){
        for(int j=i+1;j<cantRegistrosE;j++){
            if(empleados[i].getSueldo()>empleados[j].getSueldo()){
                Empleados auxE=empleados[i];
                empleados[i]=empleados[j];
                empleados[j]=auxE;
            }
        }
    }
    ///MOSTRAR EMPLEADOS
    for(int i=0;i<cantRegistrosE;i++){
        if(empleados[i].getEstado()==true) {
            empleados[i].Mostrar(); cout<<endl;
        }
    }
    delete[] empleados;
}

///ORDENAR CLIENTES
void ordenarClientePorAlfabetico(){//listo(completo)
    ArchivoClientes arc;
    int cantReg=arc.contarRegistros();
    Clientes* vecClientes=new Clientes[cantReg];
    for (int i=0;i<cantReg;i++){
        vecClientes[i]=arc.leerRegistro(i);
    }
    ///ORDENAR ALFABETICAMENTE
    for (int i=0;i<cantReg-1;i++){
        for (int a=i+1;a<cantReg;a++){
            if(strcmp(vecClientes[i].getNombre(),vecClientes[a].getNombre())>0){
                Clientes temp=vecClientes[i];
                vecClientes[i]=vecClientes[a];
                vecClientes[a]=temp;
            }
        }
    }
    cout<<" LISTA DE CLIENTES ORDENADA ALFABETICAMENTE "<<endl;
    for (int i=0;i<cantReg;i++){
        if (vecClientes[i].getEstado()==true){
            vecClientes[i].Mostrar(); cout<<endl;
        }
    }
    delete []vecClientes;
}

void ordenarClientePorDNI(){//listo(completo)
    ArchivoClientes arcC;
    int cantRegistrosC=arcC.contarRegistros();
    Clientes* clientes=new Clientes[cantRegistrosC];
    ///CARGAR CLIENTES
    for(int i=0;i<cantRegistrosC;i++){
        clientes[i]=arcC.leerRegistro(i);
    }
    ///ORDENAR CLIENTES POR DNI
    for(int i=0;i<cantRegistrosC-1;i++){
        for(int j=i+1;j<cantRegistrosC;j++){
            if(clientes[i].getDniCliente()>clientes[j].getDniCliente()){
                Clientes auxC=clientes[i];
                clientes[i]=clientes[j];
                clientes[j]=auxC;
            }
        }
    }
    ///MOSTRAR CLIENTES
    for(int i=0;i<cantRegistrosC;i++){
        if(clientes[i].getEstado()==true){
            clientes[i].Mostrar(); cout<<endl;
        }
    }
    delete[] clientes;
}

///ORDENAR VENTAS
void ordenarVentaPorFecha(){///casi listo /// Listo by adriel.
    ArchivoVentas arcV;
    int cantRegistrosV=arcV.contarRegistros();
    Ventas* ventas=new Ventas[cantRegistrosV];
    ///CARGAR VENTAS
    for(int i=0;i<cantRegistrosV;i++){
        ventas[i]=arcV.leerRegistro(i);
    }
    ///ORDENAR LAS VENTAS POR FECHA
    for(int i=0;i<cantRegistrosV-1;i++){
        for(int j=i+1;j<cantRegistrosV; j++){
                Fecha objF;
                Fecha objFdos;
                objF=ventas[i].getFechaEmision();
            if(ventas[i].getFechaEmision()<ventas[j].getFechaEmision()){
                Ventas auxV=ventas[i];
                ventas[i]=ventas[j];
                ventas[j]=auxV;
            }
        }
    }
     ///MOSTRAR VENTA
    for(int i=0;i<cantRegistrosV;i++){
        if(ventas[i].getEstado()==true){
            ventas[i].Mostrar(); cout<<endl;
        }
    }
    delete[] ventas;
}

void ordenarVentaPorImporte(){//listo(completo)
    ArchivoVentas arcV;
    int cantRegistrosV=arcV.contarRegistros();
    Ventas* ventas=new Ventas[cantRegistrosV];
    ///CARGAR VENTAS
    for(int i=0;i<cantRegistrosV;i++){
        ventas[i]=arcV.leerRegistro(i);
    }
    ///ORDENAR VENTAS POR IMPORTE
    for(int i=0;i<cantRegistrosV-1;i++){
        for(int j=i+1;j<cantRegistrosV;j++){
            if(ventas[i].getImporte()>ventas[j].getImporte()){
                Ventas auxV=ventas[i];
                ventas[i]=ventas[j];
                ventas[j]=auxV;
            }
        }
    }
    ///MOSTRAR VENTAS
    for(int i=0;i<cantRegistrosV;i++){
        if (ventas[i].getEstado()==true){
            ventas[i].Mostrar(); cout<<endl;
        }
    }
    delete[] ventas;
}

void ordenarVentaPorNumeroDeFactura(){//listo(completo)
    ArchivoVentas arcV;
    int cantRegistrosV=arcV.contarRegistros();
    Ventas* ventas=new Ventas[cantRegistrosV];
    ///CARGAR VENTAS
    for(int i=0;i<cantRegistrosV;i++){
        ventas[i]=arcV.leerRegistro(i);
    }
    ///ORDENAR VENTA POR NUMERO DE FACTURA
    for(int i=0;i<cantRegistrosV-1;i++){
        for(int j=i+1;j<cantRegistrosV;j++){
            if(ventas[i].getNumeroFactura()>ventas[j].getNumeroFactura()){
                Ventas auxV=ventas[i];
                ventas[i]=ventas[j];
                ventas[j]=auxV;
            }
        }
    }
    ///MOSTRAR VENTAS
    for(int i=0;i<cantRegistrosV;i++){
        if (ventas[i].getEstado()==true){
            ventas[i].Mostrar(); cout<<endl;
        }
    }
    delete[] ventas;
}


///FILTRAR INT�RPRETES
void filtrarInterpreteNacidoAntes(){

    ArchivoInterpretes arc;
    Interprete obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaNacimiento().getAnio()<FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarInterpreteNacidoDespues(){
    ArchivoInterpretes arc;
    Interprete obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaNacimiento().getAnio()>FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarInterpretePorLetra(){///este es el unico que al retornar un valor incorrecto que no sea una letra (como por ejemplo "}") va a volver al menu
    ArchivoInterpretes arc;
    Interprete obj;
    bool hayRegistro=false;
    char letraUser;
    cout<<"INGRESE LA LETRA: ";
    cin>>letraUser;
    cout<<endl;
    letraUser = toupper(letraUser);
    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getNombre()[0]==letraUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarInterpretePorDiscosMayor(){
    ArchivoInterpretes arcI;
    ArchivoDiscos arcD;
    Interprete obj;
    int cantRegistrosI=arcI.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Interprete* interpretes=new Interprete[cantRegistrosI];
    int* cantDiscos=new int[cantRegistrosI];
    bool hayRegistro=false;
    int cantUser;

    cout<<"INGRESE LA CANTIDAD: ";
    while(!PorSiFalla(cantUser)){
        cout<<"INGRESE LA CANTIDAD NUEVAMENTE: ";
    }
    cout<<endl;

    for(int i=0;i<cantRegistrosI;i++){
        interpretes[i]=arcI.leerRegistro(i);
        cantDiscos[i]=0;
    }

    for(int i=0;i<cantRegistrosI;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if (objD.getIDInterprete()==interpretes[i].getIDInterprete()){
                cantDiscos[i]++;
            }
        }
    }
    for(int i=0; i<cantRegistrosI; i++){
        obj = arcI.leerRegistro(i);
        if(obj.getEstado()&&cantDiscos[i]>cantUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarInterpretePorDiscosMenor(){
    ArchivoInterpretes arcI;
    ArchivoDiscos arcD;
    Interprete obj;
    int cantRegistrosI=arcI.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Interprete* interpretes=new Interprete[cantRegistrosI];//
    int* cantDiscos=new int[cantRegistrosI];
    bool hayRegistro=false;
    int cantUser;

    cout<<"INGRESE LA CANTIDAD: ";
    while(!PorSiFalla(cantUser)){
        cout<<"INGRESE LA CANTIDAD NUEVAMENTE: ";
    }
    cout<<endl;

    for(int i=0;i<cantRegistrosI;i++){
        interpretes[i]=arcI.leerRegistro(i);
        cantDiscos[i]=0;
    }

    for(int i=0;i<cantRegistrosI;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if (objD.getIDInterprete()==interpretes[i].getIDInterprete()){
                cantDiscos[i]++;
            }
        }
    }
    for(int i=0; i<cantRegistrosI; i++){
        obj = arcI.leerRegistro(i);
        if(obj.getEstado()&&cantDiscos[i]<cantUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

///FILTRAR G�NEROS
void filtrarGeneroPorLetra(){
    ArchivoGenero arc;
    Genero obj;
    bool hayRegistro=false;
    char letraUser;
    cout<<"INGRESE LA PRIMER LETRA DEL NOMBRE QUE DESEA BUSCAR: ";
    cin>>letraUser;
    cout<<endl;
    letraUser = toupper(letraUser);
    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getNombre()[0]==letraUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarGeneroPorCantidadDiscosMayor(){
    ArchivoGenero arcG;
    ArchivoDiscos arcD;
    Genero obj;
    int cantRegistrosG=arcG.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Genero* generos=new Genero[cantRegistrosG];
    int* cantDiscos=new int[cantRegistrosG];
    bool hayRegistro=false;
    int cantUser;

    cout<<"INGRESE LA CANTIDAD: ";
    while(!PorSiFalla(cantUser)){
        cout<<"INGRESE LA CANTIDAD NUEVAMENTE: ";
    }
    cout<<endl;

    for(int i=0;i<cantRegistrosG;i++){
        generos[i]=arcG.leerRegistro(i);
        cantDiscos[i]=0;
    }

    for(int i=0;i<cantRegistrosG;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if (objD.getIDGenero()==generos[i].getIDGenero()){
                cantDiscos[i]++;
            }
        }
    }
    for(int i=0; i<cantRegistrosG; i++){
        obj = arcG.leerRegistro(i);
        if(obj.getEstado()&&cantDiscos[i]>cantUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarGeneroPorCantidadDiscosMenor(){
ArchivoGenero arcG;
    ArchivoDiscos arcD;
    Genero obj;
    int cantRegistrosG=arcG.contarRegistros();
    int cantRegistrosD=arcD.contarRegistros();
    Genero* generos=new Genero[cantRegistrosG];
    int* cantDiscos=new int[cantRegistrosG];
    bool hayRegistro=false;
    int cantUser;

    cout<<"INGRESE LA CANTIDAD: ";
    while(!PorSiFalla(cantUser)){
        cout<<"INGRESE LA CANTIDAD NUEVAMENTE: ";
    }
    cout<<endl;

    for(int i=0;i<cantRegistrosG;i++){
        generos[i]=arcG.leerRegistro(i);
        cantDiscos[i]=0;
    }

    for(int i=0;i<cantRegistrosG;i++){
        for(int j=0;j<cantRegistrosD;j++){
            Discos objD=arcD.leerRegistro(j);
            if (objD.getIDGenero()==generos[i].getIDGenero()){
                cantDiscos[i]++;
            }
        }
    }
    for(int i=0; i<cantRegistrosG; i++){
        obj = arcG.leerRegistro(i);
        if(obj.getEstado()&&cantDiscos[i]<cantUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

///FILTRAR DISCOS
void filtrarDiscoPorFechaAntes(){
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaDeLanzamiento().getAnio()<FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorFechaDespues(){
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaDeLanzamiento().getAnio()>FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorLetra(){ ////////////////////////////////////////////////////////ACA QUEDE, TODAS LAS VALIDACIONES ESTAN ECHAS, SOLO QUE ALGUNAS PODRIA HACERSE OTRA FUNCION PARA LOS FLOTANTES ////////////////////////////////////////////////////////
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    char letraUser;
    cout<<"INGRESE LA PRIMER LETRA DEL NOMBRE QUE DESEA BUSCAR: ";
    cin>>letraUser;
    cout<<endl;
    letraUser = toupper(letraUser);
    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getNombreDisco()[0]==letraUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorPrecioMayor(){//ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    float precioUser;
    cout<<"INGRESE EL PRECIO A COMPARAR: ";
    cin>>precioUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getPrecio()>precioUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorPrecioMenor(){//ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    float precioUser;
    cout<<"Ingrese el precio a comparar: ";
    cin>>precioUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getPrecio()<precioUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorOrigen(){
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    char textUser[30];
    cout<<"INGRESE EL ORIGEN: ";
    cargarCadena(textUser,30);
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
//        cout<<obj.getOrigen()<<endl;
//        cout<<obj.getEstado()<<endl<<endl;

        if(obj.getEstado() && strcmp(obj.getOrigen(),textUser)==0){
            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(!hayRegistro){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorGenero(){
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    int codigo;
    cout<<"INGRESE EL CODIGO DE GENERO QUE DESEA: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DE GENERO QUE DESEA NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getIDGenero()==codigo){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarDiscoPorFormato(){
    ArchivoDiscos arc;
    Discos obj;
    bool hayRegistro=false;
    int codigo;
    cout<<"INGRESE EL CODIGO DE FORMATO QUE DESEA: ";
    while(!PorSiFalla(codigo)){
        cout<<"INGRESE EL CODIGO DE FORMATO QUE DESEA NUEVAMENTE: ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFormato()==codigo){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

///FILTRAR EMPLEADOS
void filtrarEmpleadoPorLetra(){
    ArchivoEmpleados arc;
    Empleados obj;
    bool hayRegistro=false;
    char letraUser;
    cout<<"INGRESE LA PRIMER LETRA DEL NOMBRE QUE DESEA BUSCAR: ";
    cin>>letraUser;
    cout<<endl;
    letraUser = toupper(letraUser);
    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getNombre()[0]==letraUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarEmpleadoPorSueldoMayor(){//ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoEmpleados arc;
    Empleados obj;
    bool hayRegistro=false;
    float sueldoUser;
    cout<<"INGRESE EL SUELDO A COMPARAR: ";
    cin>>sueldoUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getSueldo()>sueldoUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarEmpleadoPorSueldoMenor(){//ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoEmpleados arc;
    Empleados obj;
    bool hayRegistro=false;
    float sueldoUser;
    cout<<"INGRESE EL SUELDO A COMPARAR: ";
    cin>>sueldoUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getSueldo()<sueldoUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

///FILTRAR CLIENTES
void filtrarClientePorLetra(){
    ArchivoClientes arc;
    Clientes obj;
    bool hayRegistro=false;
    char letraUser;
    cout<<"INGRESE LA PRIMER LETRA DEL NOMBRE QUE DESEA BUSCAR: ";
    cin>>letraUser;
    cout<<endl;
    letraUser = toupper(letraUser);
    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getNombre()[0]==letraUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarClientePorDNIMenor(){
    ArchivoClientes arc;
    Clientes obj;
    bool hayRegistro=false;
    int numUser;
    cout<<"INGRESE EL NUMERO DE DNI A COMPARAR (SIN PUNTOS)";
    while(!PorSiFalla(numUser)){
        cout<<"INGRESE EL NUMERO DE DNI A COMPARAR NUEVAMENTE (SIN PUNTOS): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getDniCliente()<numUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarClientePorDNIMayor(){
    ArchivoClientes arc;
    Clientes obj;
    bool hayRegistro=false;
    int numUser;
    cout<<"INGRESE EL NUMERO DE DNI A COMPARAR (SIN PUNTOS): ";
    while(!PorSiFalla(numUser)){
        cout<<"INGRESE EL NUMERO DE DNI A COMPARAR NUEVAMENTE (SIN PUNTOS): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getDniCliente()>numUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"No se encontraron registros. "<<endl<<endl;
    }
}

///FILTRAR VENTAS
void filtrarVentaPorFechaAntes(){
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE (ENTERO): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaEmision().getAnio()<FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarVentaPorFechaDespues(){
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    int FechaUser;
    cout<<"INGRESE EL ANIO A COMPARAR: ";
    while(!PorSiFalla(FechaUser)){
        cout<<"INGRESE EL ANIO A COMPARAR NUEVAMENTE (ENTERO): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getFechaEmision().getAnio()>FechaUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarVentaPorImporteMayor(){ //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    float impUser;
    cout<<"INGRESE EL IMPORTE A COMPARAR: ";
    cin>>impUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getImporte()>impUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarVentaPorImporteMenor(){ //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    float impUser;
    cout<<"INGRESE EL IMPORTE A COMPARAR: ";
    cin>>impUser;
    if(cin.fail()){
    cin.clear();
    cin.ignore(10000,'\n');
    cout<<"ENTRADA INVALIDA, PORFAVOR, INGRESE UN NUMERO (FLOTANTE)."<<endl; //ESTO PUEDE SER REMPLAZADO POR UNA FUNCION
    return;
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getImporte()<impUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarVentaPorEmpleado(){
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    int numUser;
    cout<<"INGRESE EL DNI DEL EMPLEADO A COMPARAR: ";
    while(!PorSiFalla(numUser)){
        cout<<"INGRESE EL DNI DEL EMPLEADO A COMPARAR NUEVAMENTE (ENTERO): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getDniEmpleado()==numUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

void filtrarVentaPorCliente(){
    ArchivoVentas arc;
    Ventas obj;
    bool hayRegistro=false;
    int numUser;
    cout<<"INGRESE EL DNI DEL CLIENTE A COMPARAR: ";
    while(!PorSiFalla(numUser)){
        cout<<"INGRESE EL DNI DEL CLIENTE A COMPARAR NUEVAMENTE (ENTERO): ";
    }
    cout<<endl;

    int cantReg = arc.contarRegistros();
    for(int i=0; i<cantReg; i++){
        obj = arc.leerRegistro(i);
        if(obj.getEstado()&&obj.getDniEmpleado()==numUser){

            obj.Mostrar();
            cout<<endl;
            hayRegistro=true;
        }
    }
    if(hayRegistro==false){
        cout<<"NO SE ENCONTRARON REGISTROS. "<<endl<<endl;
    }
}

///FILTRAR DETALLE X VENTA
void filtrarDetallePorVenta(){
    ArchivoVentas arcV;
    ArchivoDetalleVenta arcD;
    Ventas objV;
    DetalleVenta objD;
    bool hayRegistro=false, hayDetalle=false;
    int numUser;
    cout<<"INGRESE EL NUMERO DE LA FACTURA: ";
    while(!PorSiFalla(numUser)){ //reintenta hasta que la entrada sea un entero
        cout<<"INGRESE EL NUMERO DE LA FACTURA NUEVAMENTE (ENTERO): ";
    }
    cout<<endl;
    int cantRegD = arcD.contarRegistros();
    int cantRegV = arcV.contarRegistros();
    //cout<<"=========== FACTURA =========="<<endl;

    //Buscar la factura en el archivo de ventas
    for(int i=0; i<cantRegV; i++){
        objV = arcV.leerRegistro(i);

        if(objV.getEstado()&&objV.getNumeroFactura()==numUser){
            objV.Mostrar();
            cout<<endl;
            hayRegistro=true;
            break; //Termina el bucle si encuentra la factura, no recuerdo si el numero de factura es unico, si es asi, se deja el break, sino, eliminarlo.
        }
    }
    if(hayRegistro==false){ cout<<"NO SE ENCONTRARON FACTURAS CON ESE CODIGO."<<endl<<endl;}
    else{
        cout<<" DETALLE: "<<endl<<endl;
        for(int i=0; i<cantRegD; i++){
            objD = arcD.leerRegistro(i);
            if(objD.getEstado()&&objD.getNumeroFactura()==numUser){ // antes comparaba objV

                objD.Mostrar();

                cout<<endl;
                hayDetalle=true;
            }
        }
        if(hayDetalle==false){ cout<<"AUN NO SE AGREGARON PRODUCTOS A LA COMPRA. "<<endl<<endl;}
    }

}

///COMPROBAR

bool comprobarInterprete(int id){
    ArchivoInterpretes arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

bool comprobarGenero(int id){
    ArchivoGenero arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

bool comprobarDisco(int id){
    ArchivoDiscos arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

bool comprobarCliente(int id){
    ArchivoClientes arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

bool comprobarEmpleado(int id){
    ArchivoEmpleados arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

bool comprobarVenta(int id){
    ArchivoVentas arc;
    int pos = arc.buscarRegistro(id);
    if(pos >= 0){
        return arc.leerRegistro(pos).getEstado();
    }
    return false;
}

///MENUES
void menuPrincipal(){
    int opc;
    while(true){
        system("cls");
        cout<<"       MENU PRINCIPAL"<<endl;
        cout<<"============================="<<endl;
        cout<<" 1 - MENU INTERPRETES"<<endl;
        cout<<" 2 - MENU GENEROS"<<endl;
        cout<<" 3 - MENU DISCOS"<<endl;
        cout<<" 4 - MENU EMPLEADOS"<<endl;
        cout<<" 5 - MENU CLIENTES"<<endl;
        cout<<" 6 - MENU VENTAS"<<endl;
        cout<<" 0 - SALIR DEL PROGRAMA"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                menuInterpretes();
                break;
            case 2:
                menuGeneros();
                break;
            case 3:
                menuDiscos();
                break;
            case 4:
                menuEmpleados();
                break;
            case 5:
                menuClientes();
                break;
            case 6:
                menuVentas();
                break;
            case 0:
                return;
        }
    }
}

void menuInterpretes(){
    int opc;
    while(true){
        system("cls");
        cout<<"       MENU INTERPRETES"<<endl;
        cout<<"=============================="<<endl;
        cout<<" 1 - ALTA INTERPRETE"<<endl;
        cout<<" 2 - BAJA INTERPRETE"<<endl;
        cout<<" 3 - MODIFICAR INTERPRETE"<<endl;
        cout<<" 4 - LISTAR INTERPRETES"<<endl;
        cout<<" 5 - ORDENAR INTERPRETES"<<endl;
        cout<<" 6 - FILTRAR INTERPRETES"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"=============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaInterprete();
                break;
            case 2:
                bajaInterprete();
                break;
            case 3:
                menuModificarInterprete();
                break;
            case 4:
                listarInterpretes();
                break;
            case 5:
                menuOrdenarInterpretes();
                break;
            case 6:
                menuFiltrarInterpretes();
               break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarInterprete(){
    int opc;
    while(true){
        system("cls");
        cout<<"   MENU MODIFICAR INTERPRETES"<<endl;
        cout<<"================================"<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - NOMBRE"<<endl;
        cout<<" 2 - APELLIDO"<<endl;
        cout<<" 3 - FECHA DE NACIMIENTO"<<endl;
        cout<<" 0 - VOLVER AL MENU INTERPRETES"<<endl;
        cout<<"================================"<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarNombreInterprete();
                break;
            case 2:
                modificarApellidoInterprete();
                break;
            case 3:
                modificarFechaInterprete();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarInterpretes(){
    int opc;
    while(true){
        system("cls");
        cout<<"   MENU ORDENAR INTERPRETES"<<endl;
        cout<<"==============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - FECHA DE NACIMIENTO"<<endl;
        cout<<" 2 - ORDEN ALFABETICO"<<endl;
        cout<<" 3 - CANTIDAD DE DISCOS"<<endl;
        cout<<" 0 - VOLVER AL MENU INTERPRETES"<<endl;
        cout<<"==============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarInterpretePorFecha();
                break;
            case 2:
                ordenarInterpretePorAlfabetico();
                break;
            case 3:
                ordenarInterpretePorCantidadDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuFiltrarInterpretes(){
    int opc;
    while(true){
        system("cls");
        cout<<"      MENU FILTRAR INTERPRETES"<<endl;
        cout<<"====================================="<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - INTERPRETES NACIDOS ANTES DE..."<<endl;
        cout<<" 2 - INTERPRETES NACIDOS DESPUES DE..."<<endl;
        cout<<" 3 - PRIMERA LETRA DEL NOMBRE"<<endl;
        cout<<" 4 - CANTIDAD DE DISCOS MAYOR A..."<<endl;
        cout<<" 5 - CANTIDAD DE DISCOS MENOR A..."<<endl;
        cout<<" 0 - VOLVER AL MENU INTERPRETES"<<endl;
        cout<<"====================================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarInterpreteNacidoAntes();
                break;
            case 2:
                filtrarInterpreteNacidoDespues();
                break;
            case 3:
                filtrarInterpretePorLetra();
                break;
            case 4:
                filtrarInterpretePorDiscosMayor();
                break;
            case 5:
                filtrarInterpretePorDiscosMenor();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"        MENU GENEROS"<<endl;
        cout<<"=============================="<<endl;
        cout<<" 1 - ALTA GENERO"<<endl;
        cout<<" 2 - BAJA GENERO"<<endl;
        cout<<" 3 - MODIFICAR GENERO"<<endl;
        cout<<" 4 - LISTAR GENEROS"<<endl;
        cout<<" 5 - ORDENAR GENEROS"<<endl;
        cout<<" 6 - FILTRAR GENEROS"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"=============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaGenero();
                break;
            case 2:
                bajaGenero();
                break;
            case 3:
                menuModificarGeneros();
                break;
            case 4:
                listarGeneros();
                break;
            case 5:
                menuOrdenarGeneros();
                break;
            case 6:
                menuFiltrarGeneros();
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU MODIFICAR GENERO"<<endl;
        cout<<"============================="<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - NOMBRE"<<endl;
        cout<<" 0 - VOLVER AL MENU GENERO"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarNombreGenero();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU ORDENAR GENEROS"<<endl;
        cout<<"============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - ORDEN ALFABETICO"<<endl;
        cout<<" 2 - CANTIDAD DE DISCOS"<<endl;
        cout<<" 0 - VOLVER AL MENU GENEROS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarGeneroPorAlfabetico();
                break;
            case 2:
                ordenarGeneroPorCantidadDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuFiltrarGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"        MENU FILTRAR GENEROS"<<endl;
        cout<<"======================================"<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - PRIMERA LETRA DEL NOMBRE DE GENERO"<<endl;
        cout<<" 2 - CANTIDAD DE DISCOS MAYOR A..."<<endl;
        cout<<" 3 - CANTIDAD DE DISCOS MENOR A..."<<endl;
        cout<<" 0 - VOLVER AL MENU GENEROS"<<endl;
        cout<<"======================================"<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarGeneroPorLetra();
                break;
            case 2:
                filtrarGeneroPorCantidadDiscosMayor();
                break;
            case 3:
                filtrarGeneroPorCantidadDiscosMenor();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"         MENU DISCOS"<<endl;
        cout<<"=============================="<<endl;
        cout<<" 1 - ALTA DISCO"<<endl;
        cout<<" 2 - BAJA DISCO"<<endl;
        cout<<" 3 - MODIFICAR DISCO"<<endl;
        cout<<" 4 - LISTAR DISCOS"<<endl;
        cout<<" 5 - ORDENAR DISCOS"<<endl;
        cout<<" 6 - FILTRAR DISCOS"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"=============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaDisco();
                break;
            case 2:
                bajaDisco();
                break;
            case 3:
                menuModificarDiscos();
                break;
            case 4:
                listarDiscos();
                break;
            case 5:
                menuOrdenarDiscos();
                break;
            case 6:
                menuFiltrarDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"   MENU MODIFICAR DISCOS"<<endl;
        cout<<"==========================="<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - INTERPRETE"<<endl;
        cout<<" 2 - GENERO"<<endl;
        cout<<" 3 - ORIGEN"<<endl;
        cout<<" 4 - PRECIO"<<endl;
        cout<<" 5 - FORMATO"<<endl;
        cout<<" 6 - FECHA DE LANZAMIENTO"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"==========================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarInterpreteDisco();
                break;
            case 2:
                modificarGeneroDisco();
                break;
            case 3:
                modificarOrigenDisco();
                break;
            case 4:
                modificarPrecioDisco();
                break;
            case 5:
                modificarFormatoDisco();
                break;
            case 6:
                modificarFechaDisco();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"     MENU ORDENAR DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - FECHA DE LANZAMIENTO"<<endl;
        cout<<" 2 - ORDEN ALFABETICO"<<endl;
        cout<<" 3 - PRECIO"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarDiscoPorFecha();
                break;
            case 2:
                ordenarDiscoPorAlfabetico();
                break;
            case 3:
                ordenarDiscoPorPrecio();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}


void menuFiltrarDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"      MENU FILTRAR DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - LANZADOS ANTES DE..."<<endl;
        cout<<" 2 - LANZADOS DESPUES DE..."<<endl;
        cout<<" 3 - PRIMERA LETRA DEL DISCO"<<endl;
        cout<<" 4 - PRECIO MAYOR A..."<<endl;
        cout<<" 5 - PRECIO MENOR A..."<<endl;
        cout<<" 6 - ORIGEN"<<endl;
        cout<<" 7 - GENERO"<<endl;
        cout<<" 8 - FORMATO"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarDiscoPorFechaAntes();
                break;
            case 2:
                filtrarDiscoPorFechaDespues();
                break;
            case 3:
                filtrarDiscoPorLetra();
                break;
            case 4:
                filtrarDiscoPorPrecioMayor();
                break;
            case 5:
                filtrarDiscoPorPrecioMenor();
                break;
            case 6:
                filtrarDiscoPorOrigen();
                break;
            case 7:
                filtrarDiscoPorGenero();
                break;
            case 8:
                filtrarDiscoPorFormato();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"        MENU EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" 1 - ALTA EMPLEADO"<<endl;
        cout<<" 2 - BAJA EMPLEADO"<<endl;
        cout<<" 3 - MODIFICAR EMPLEADO"<<endl;
        cout<<" 4 - LISTAR EMPLEADOS"<<endl;
        cout<<" 5 - ORDENAR EMPLEADOS"<<endl;
        cout<<" 6 - FILTRAR EMPLEADOS"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaEmpleado();
                break;
            case 2:
                bajaEmpleado();
                break;
            case 3:
                menuModificarEmpleados();
                break;
            case 4:
                listarEmpleados();
                break;
            case 5:
                menuOrdenarEmpleados();
                break;
            case 6:
                menuFiltrarEmpleados();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"  MENU MODIFICAR EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - NOMBRE"<<endl;
        cout<<" 2 - APELLIDO"<<endl;
        cout<<" 3 - SUELDO"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarNombreEmpleado();
                break;
            case 2:
                modificarApellidoEmpleado();
                break;
            case 3:
                modificarSueldoEmpleado();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU ORDENAR EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - NUMERO DE DNI"<<endl;
        cout<<" 2 - ORDEN ALFABETICO"<<endl;
        cout<<" 3 - SUELDO"<<endl;
        cout<<" 0 - VOLVER AL MENU EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarEmpleadoPorDNI();
                break;
            case 2:
                ordenarEmpleadoPorAlfabetico();
                break;
            case 3:
                ordenarEmpleadoPorSueldo();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuFiltrarEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"   MENU FILTRAR EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - PRIMERA LETRA DEL NOMBRE"<<endl;
        cout<<" 2 - SUELDO MAYOR A..."<<endl;
        cout<<" 3 - SUELDO MENOR A..."<<endl;
        cout<<" 0 - VOLVER AL MENU EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarEmpleadoPorLetra();
                break;
            case 2:
                filtrarEmpleadoPorSueldoMayor();
                break;
            case 3:
                filtrarEmpleadoPorSueldoMenor();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"       MENU CLIENTES"<<endl;
        cout<<"============================="<<endl;
        cout<<" 1 - ALTA CLIENTE"<<endl;
        cout<<" 2 - BAJA CLIENTE"<<endl;
        cout<<" 3 - MODIFICAR CLIENTE"<<endl;
        cout<<" 4 - LISTAR CLIENTES"<<endl;
        cout<<" 5 - ORDENAR CLIENTES"<<endl;
        cout<<" 6 - FILTRAR CLIENTES"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaCliente();
                break;
            case 2:
                bajaCliente();
                break;
            case 3:
                menuModificarClientes();
                break;
            case 4:
                listarClientes();
                break;
            case 5:
                menuOrdenarClientes();
                break;
            case 6:
                menuFiltrarClientes();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"   MENU MODIFICAR CLIENTES"<<endl;
        cout<<"============================="<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - NOMBRE"<<endl;
        cout<<" 2 - APELLIDO"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarNombreCliente();
                break;
            case 2:
                modificarApellidoCliente();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU ORDENAR CLIENTES"<<endl;
        cout<<"============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - NUMERO DE DNI"<<endl;
        cout<<" 2 - ORDEN ALFABETICO"<<endl;
        cout<<" 0 - VOLVER AL MENU CLIENTES"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarClientePorDNI();
                break;
            case 2:
                ordenarClientePorAlfabetico();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuFiltrarClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU FILTRAR CLIENTES"<<endl;
        cout<<"============================="<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - PRIMERA LETRA DEL NOMBRE"<<endl;
        cout<<" 2 - DNI MAYOR A..."<<endl;
        cout<<" 3 - DNI MENOR A..."<<endl;
        cout<<" 0 - VOLVER AL MENU EMPLEADOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarClientePorLetra();
                break;
            case 2:
                filtrarClientePorDNIMayor();
                break;
            case 3:
                filtrarClientePorDNIMenor();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"        MENU VENTAS"<<endl;
        cout<<"============================="<<endl;
        cout<<" 1 - ALTA VENTA"<<endl;
        cout<<" 2 - BAJA VENTA"<<endl;
        cout<<" 3 - MODIFICAR VENTA"<<endl;
        cout<<" 4 - LISTAR VENTAS"<<endl;
        cout<<" 5 - ORDENAR VENTAS"<<endl;
        cout<<" 6 - FILTRAR VENTAS"<<endl;
        cout<<" 7 - FILTRAR DETALLE DE VENTA"<<endl;
        cout<<" 0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                altaVenta();
                break;
            case 2:
                bajaVenta();
                break;
            case 3:
                menuModificarVentas();
                break;
            case 4:
                listarVentas();
                break;
            case 5:
                menuOrdenarVentas();
                break;
            case 6:
                menuFiltrarVentas();
                break;
            case 7:
                filtrarDetallePorVenta();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuModificarVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU MODIFICAR VENTAS"<<endl;
        cout<<"============================="<<endl;
        cout<<" MODIFICAR:"<<endl;
        cout<<" 1 - DNI EMPLEADO"<<endl;
        cout<<" 2 - DNI CLIENTE"<<endl;
        cout<<" 3 - IMPORTE"<<endl;
        cout<<" 4 - FECHA EMISION"<<endl;
        cout<<" 0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                modificarDNIEmpleadoVenta();
                break;
            case 2:
                modificarDNIClienteVenta();
                break;
            case 3:
                modificarImporteVenta();
                break;
            case 4:
                modificarFechaVenta();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"     MENU ORDENAR VENTAS"<<endl;
        cout<<"============================="<<endl;
        cout<<" ORDENAR POR:"<<endl;
        cout<<" 1 - FECHA DE EMISION"<<endl;
        cout<<" 2 - IMPORTE TOTAL"<<endl;
        cout<<" 3 - NUMERO DE FACTURA"<<endl;
        cout<<" 0 - VOLVER AL MENU VENTAS"<<endl;
        cout<<"============================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                ordenarVentaPorFecha();
                break;
            case 2:
                ordenarVentaPorImporte();
                break;
            case 3:
                ordenarVentaPorNumeroDeFactura();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuFiltrarVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"      MENU FILTRAR VENTAS"<<endl;
        cout<<"================================"<<endl;
        cout<<" FILTRAR POR:"<<endl;
        cout<<" 1 - FECHA DE EMISION ANTES DE..."<<endl;
        cout<<" 2 - FECHA DE EMISION DESPUES DE..."<<endl;
        cout<<" 3 - IMPORTE MAYOR A..."<<endl;
        cout<<" 4 - IMPORTE MENOR A..."<<endl;
        cout<<" 5 - EMPLEADO"<<endl;
        cout<<" 6 - CLIENTE"<<endl;
        cout<<" 0 - VOLVER AL MENU VENTAS"<<endl;
        cout<<"================================="<<endl;
        cout<<" INGRESE LA OPCION: ";
        while(!PorSiFalla(opc)){
        cout<<"INGRESE EL OPCION NUEVAMENTE: ";
        }
        system("cls");
        switch(opc){
            case 1:
                filtrarVentaPorFechaAntes();
                break;
            case 2:
                filtrarVentaPorFechaDespues();
                break;
            case 3:
                filtrarVentaPorImporteMayor();
                break;
            case 4:
                filtrarVentaPorImporteMenor();
                break;
            case 5:
                filtrarVentaPorEmpleado();
                break;
            case 6:
                filtrarVentaPorCliente();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}
