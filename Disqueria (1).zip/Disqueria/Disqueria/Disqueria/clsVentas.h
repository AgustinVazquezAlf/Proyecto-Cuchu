#ifndef CLSVENTAS_H_INCLUDED
#define CLSVENTAS_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
#include "clsDetalleVenta.h"
using namespace std;

class Ventas{
    private:
        int _numeroFactura;
        int _dniEmpleado;
        int _dniCliente;
        float _importe;
        Fecha _fechaEmision;
        bool _estado;
    public:
        int getNumeroFactura();
        float getImporte();
        Fecha getFechaEmision();
        int getDniEmpleado();
        int getDniCliente();
        bool getEstado();
        void setNumeroFactura (int numeroFactura);
        void setImporte (float importe);
        void setFechaEmision (Fecha fechaEmision);
        void setDniEmpleado (int dniEmpleado);
        void setDniCliente (int dniCliente);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar(int numeroFactura);
        float cargarDetalle(int);
};


#endif // CLSVENTAS_H_INCLUDED
