#ifndef CLSFECHA_H_INCLUDED
#define CLSFECHA_H_INCLUDED
#include <iostream>
#include "Funciones.h"
class Fecha{
    private:
        int dia, mes, anio;
    public:
        Fecha(int d=0, int m=0, int a=0);
        void Mostrar();
        bool Cargar();
        int getAnio();
        int getMes();
        int getDia();
        bool operator<(const Fecha& otra) const;
//        friend ostream& operator<<(ostream &salida, const Fecha& obj);
};

#endif // CLSFECHA_H_INCLUDED
