#include <iostream>
using namespace std;
#include "clsEmpleados.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int  Empleados::getDniEmpleado(){
    return _dniEmpleado;
}

float Empleados::getSueldo(){
    return _sueldo;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Empleados::setDniEmpleado (int dniEmpleado){
    _dniEmpleado=dniEmpleado;
}

void Empleados::setSueldo (float sueldo){
    _sueldo=sueldo;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Empleados::Mostrar(){
    cout<<"DNI EMPLEADO: "<<_dniEmpleado<<endl;
    Personas::Mostrar();
    cout<<"SUELDO: "<<_sueldo<<endl;
}

void Empleados::Cargar(int dni){
    setDniEmpleado(dni);
    Personas::Cargar();
    cout<<"SUELDO: ";
    float sueldo;
    while(!PorSiFallaPrecio(sueldo)){
        cout<<"INGRESE EL SUELDO NUEVAMENTE: ";
    }
    setSueldo(sueldo);
    setEstado(true);
}
