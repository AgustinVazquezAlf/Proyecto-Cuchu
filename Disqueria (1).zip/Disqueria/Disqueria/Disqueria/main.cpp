#include <iostream>
#include "clsClientes.h"
#include "Funciones.h"
#include "rlutil.h"
using namespace std;

int main()
{
    color();
    menuPrincipal();
    return 0;
}
