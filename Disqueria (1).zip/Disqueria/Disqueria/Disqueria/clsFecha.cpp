#include <iostream>
#include "clsFecha.h"
using namespace std;
#include "Funciones.h"

Fecha::Fecha(int d, int m, int a){
    dia=d;
    mes=m;
    anio=a;
}

bool Fecha::Cargar(){
    cout<<"DIA: ";
    while(!porSiFallaDia(dia)){
        cout<<"INGRESE EL DIA NUEVAMENTE: ";
    }
    cout<<"MES: ";
    while(!porSiFallaMes(mes)){
        cout<<"INGRESE EL MES NUEVAMENTE: ";
    }
    cout<<"ANIO: ";
    while(!porSiFallaAnio(anio)){
        cout<<"INGRESE EL ANIO NUEVAMENTE: ";
    }
}

void Fecha::Mostrar(){
    cout<<"FECHA: "<<dia<<"/"<<mes<<"/"<<anio<<endl;
}

int Fecha::getAnio(){
    return anio;
}

int Fecha::getMes(){
    return mes;
}

int Fecha::getDia(){
    return dia;
}

bool Fecha::operator<(const Fecha& otra) const{
    if(anio>otra.anio) return true;
    if(anio<otra.anio) return false;
    if(mes>otra.mes) return true;
    if(mes<otra.mes)return false;
    if(dia>otra.dia)return true;
    if(dia<otra.dia)return false;
    return dia>otra.dia;
}
//
//ostream& operator<<(ostream& salida, const Fecha& obj) {
//    salida << obj.dia << "/" << obj.mes << "/" << obj.anio;
//    return salida;
//}
