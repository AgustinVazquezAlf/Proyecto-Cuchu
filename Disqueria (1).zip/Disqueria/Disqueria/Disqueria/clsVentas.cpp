#include <iostream>
#include <iomanip>
using namespace std;
#include "clsVentas.h"
#include "Funciones.h"
#include "clsDetalleVenta.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Ventas::getNumeroFactura(){
    return _numeroFactura;
}

float Ventas::getImporte(){
    return _importe;
}

Fecha Ventas::getFechaEmision(){
    return _fechaEmision;
}

int Ventas::getDniEmpleado(){
    return _dniEmpleado;
}

int Ventas::getDniCliente(){
    return _dniCliente;
}

bool Ventas::getEstado(){
    return _estado;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Ventas::setNumeroFactura (int numeroFactura){
    _numeroFactura=numeroFactura;
}

void Ventas::setImporte (float importe){
    _importe=importe;
}

void Ventas::setFechaEmision (Fecha fechaEmision){
    _fechaEmision=fechaEmision;
}

void Ventas::setDniEmpleado (int dniEmpleado){
    _dniEmpleado=dniEmpleado;
}

void Ventas::setDniCliente (int dniCliente){
    _dniCliente=dniCliente;
}

void Ventas::setEstado (bool estado){
    _estado=estado;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void Ventas::Mostrar(){
    _fechaEmision.Mostrar();
    cout<<"COD. FACTURA: "<<_numeroFactura<<endl;
    cout<<"COD. EMPLEADO: "<<_dniEmpleado<<endl;
    cout<<"COD. CLIENTE: "<<_dniCliente<<endl;
    cout<<fixed<<std::setprecision(2)<<"IMPORTE: "<<_importe<<endl;
}

float Ventas::cargarDetalle(int nF){
    DetalleVenta obj;
    float importe=0;
    int cero=-1;
    int codigo;
    cout<<"EMPIEZA LA CARGA DEL DETALLE DE VENTA"<<endl;
    while(cero!=0){
        obj=altaDetalleVenta(nF);
        importe+=obj.getPrecio()*obj.getCantidad();
    cout<<"Ingrese 0 para terminar el registro. "<<endl;
    cout<<"Ingrese cualquier otro numero para seguir el registro. "<<endl;
    while(!PorSiFalla(cero)){
    cout<<"Ingrese 0 para terminar el registro. "<<endl;
    cout<<"Ingrese cualquier otro numero positivo para seguir el registro. "<<endl;
    }
    }
    cout<<"IMPORTE: "<<importe<<endl;
    setImporte(importe);

}

void Ventas::Cargar(int numeroFactura){

    int dniEmpleado, dniCliente;
    Fecha fechaEmision;
    fechaEmision.Cargar();

    cout<<"COD. EMPLEADO: ";
    cin>>dniEmpleado;
        if(!comprobarEmpleado(dniEmpleado)){
        cout<<"EL DNI DEL EMPLEADO INGRESADO NO EXISTE EN EL ARCHIVO DE EMPLEADOS"<<endl;
        return;
    }
    cout<<"COD. CLIENTE: ";
    cin>>dniCliente;
        if(!comprobarCliente(dniCliente)){
        cout<<"EL DNI DEL CLIENTE INGRESADO NO EXISTE EN EL ARCHIVO DE CLIENTES"<<endl;
        return;
    }

    cargarDetalle(numeroFactura);
    setNumeroFactura(numeroFactura);
    setEstado(true);
    setDniEmpleado(dniEmpleado);
    setDniCliente(dniCliente);
    setFechaEmision(fechaEmision);
    setImporte(_importe);
}
