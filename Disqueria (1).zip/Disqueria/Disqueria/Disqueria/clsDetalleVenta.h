#ifndef CLSDETALLEVENTA_H_INCLUDED
#define CLSDETALLEVENTA_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class DetalleVenta{
    private:
        int _numeroFactura;
        int _codigoDeBarras;
        float _precio;
        int _cantidad;
        bool _estado;
    protected:
        float _importe;
    public:
        int getCodigoDeBarras();
        int getCantidad();
        int getNumeroFactura();
        float getPrecio();
        bool getEstado();
        void setCodigoDeBarras (int codigoDeBarras);
        void setNumeroFactura(int numeroFactura);
        void setCantidad (int cantidad);
        void setPrecio (int precio);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar(int codigo, int numeroFactura, float precio);
};


#endif // CLSDETALLEVENTA_H_INCLUDED
