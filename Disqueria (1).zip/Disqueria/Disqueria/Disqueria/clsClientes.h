#ifndef CLSCLIENTES_H_INCLUDED
#define CLSCLIENTES_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
#include "clsPersonas.h"
using namespace std;

class Clientes : public Personas{
    private:
        int _dniCliente;
    public:
        Clientes();
        ~Clientes();
        int getDniCliente();
        void setDniCliente (int dniCliente);
        void Mostrar();
        void Cargar(int dni);
};

#endif // CLSCLIENTES_H_INCLUDED
