#include <iostream>
using namespace std;
#include "clsInterprete.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Interprete::getIDInterprete(){
    return _IDInterprete;
}

Fecha Interprete::getFechaNacimiento(){
    return _fechaNacimiento;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Interprete::setIdInterprete (int IDInterprete){
    _IDInterprete=IDInterprete;
}

void Interprete::setFechaNacimiento (Fecha fechaNacimiento){
    _fechaNacimiento=fechaNacimiento;
}

void Interprete::Mostrar(){
    cout<<"ID: "<<_IDInterprete<<endl;
    Personas::Mostrar();
    _fechaNacimiento.Mostrar();
}

void Interprete::Cargar(int id){
    setIdInterprete(id);
    Personas::Cargar();
    cout<<"FECHA NACIMIENTO: "<<endl;
    _fechaNacimiento.Cargar();
    setEstado(true);

}
