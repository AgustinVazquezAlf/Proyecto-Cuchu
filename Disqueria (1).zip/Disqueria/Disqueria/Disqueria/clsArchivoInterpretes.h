#ifndef CLSARCHIVOINTERPRETES_H_INCLUDED
#define CLSARCHIVOINTERPRETES_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoInterpretes{
    private:
        char nombre[30];
    public:
        ArchivoInterpretes (const char *n="interprete.dat");
        Interprete leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Interprete);
        bool modificarRegistro (Interprete, int);
        void listarRegistros();

};


#endif // CLSARCHIVOINTERPRETES_H_INCLUDED
