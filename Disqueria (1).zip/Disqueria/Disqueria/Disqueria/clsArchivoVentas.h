#ifndef CLSARCHIVOVENTAS_H_INCLUDED
#define CLSARCHIVOVENTAS_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoVentas{
    private:
        char nombre[30];
    public:
        ArchivoVentas (const char *n="ventas.dat");
        Ventas leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Ventas);
        bool modificarRegistro (Ventas, int);
        void listarRegistros();

};


#endif // CLSARCHIVOVENTAS_H_INCLUDED
