#include <iostream>
#include <cstring>
#include "clsVentas.h"
#include "clsArchivoVentas.h"
using namespace std;

ArchivoVentas::ArchivoVentas(const char *n){
    strcpy(nombre, n);
}

Ventas ArchivoVentas::leerRegistro(int pos){
    FILE *p;
    Ventas obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setNumeroFactura(-2);
        return obj;
    }
    obj.setNumeroFactura(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoVentas::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Ventas);
}

int ArchivoVentas::buscarRegistro(int id){
    int cantReg = contarRegistros();
    Ventas obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getNumeroFactura()==id){
            return i;
        }
    }
    return -1;
}

bool ArchivoVentas::grabarRegistro(Ventas obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoVentas::modificarRegistro(Ventas obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoVentas::listarRegistros(){
    int cantReg = contarRegistros();
    Ventas obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}

