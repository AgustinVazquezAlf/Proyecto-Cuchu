#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
/////////////YANET
using namespace std;

#include "clsDetalleVenta.h"
void color();
void cargarCadena(char *pal, int tam);
float obtenerPrecioDisco(int codigo);
///PorSIFalla
bool PorSiFalla(int &VALORGENERICO);
bool PorSiFallaDetalleVenta(int &VALORGENERICO);
bool PorSiFallaPrecio(float &VALORGENERICO);
bool porSiFallaDia(int &dia);
bool porSiFallaMes(int &mes);
bool porSiFallaAnio(int &anio);
void altaInterprete();
void bajaInterprete();
void modificarInterprete();
void listarInterpretes();
void ordenarInterpretePorFecha();
void ordenarInterpretePorAlfabetico();
void ordenarInterpretePorCantidadDiscos();
void ordenarGeneroPorAlfabetico();
void ordenarGeneroPorCantidadDiscos();
///COMPROBAR
bool comprobarInterprete(int); //comprueba que el id interprete existe
bool comprobarGenero(int); //comprueba que el id genero existe
bool comprobarDisco(int); //comprueba que el codigo del disco existe
bool comprobarEmpleado(int); //comprueba que el dni del empleado existe
bool comprobarCliente(int); //comprueba que el dni del empleado existe
bool comprobarVenta(int); //comprueba que el numero de factura existe
///MENU
void menuPrincipal();
///SUB MENUES
void menuInterpretes();
void menuGeneros();
void menuDiscos();
void menuEmpleados();
void menuClientes();
void menuVentas();
void menuDetalleVenta();
///SUB-SUB MENUES
void menuModificarInterprete();
void menuOrdenarInterpretes();
void menuFiltrarInterpretes();
void menuModificarGeneros();
void menuOrdenarGeneros();
void menuFiltrarGeneros();
void menuModificarDiscos();
void menuOrdenarDiscos();
void menuFiltrarDiscos();
void menuModificarEmpleados();
void menuOrdenarEmpleados();
void menuFiltrarEmpleados();
void menuModificarClientes();
void menuOrdenarClientes();
void menuFiltrarClientes();
void menuModificarVentas();
void menuOrdenarVentas();
void menuFiltrarVentas();
void menuModificarDetalleVenta();
void menuOrdenarDetalleVenta();
DetalleVenta altaDetalleVenta(int numeroFactura);

#endif // FUNCIONES_H_INCLUDED
